//add by Golden 20081030 for LX800

#if LINUX_VERSION_CODE == KERNEL_VERSION(2,6,18)
#define LX800
#else
#define PXA270
#endif
