/*************************************************************************
 * errexit.h
 *
 * v 0.0.0 2000.05.16 by Reed Lai
 *
 * head of errexit.c
 *
 * History
 *
 * v 0.0.0 2000.05.16 by Reed Lai
 * create
 *************************************************************************/
#ifndef ERREXIT_H
#define ERREXIT_H

#include <varargs.h>
#include <stdio.h>

extern int errno;

#endif							/* ERREXIT_H */
