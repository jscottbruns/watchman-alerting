main()
{
	printf("Hi ~ Welcome to LinCon-8000\n");
}
